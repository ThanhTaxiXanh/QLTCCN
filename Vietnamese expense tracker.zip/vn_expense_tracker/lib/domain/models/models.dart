// lib/domain/models/wallet_model.dart
import 'package:equatable/equatable.dart';

class WalletModel extends Equatable {
  final String id;
  final String name;
  final String currency;
  final int initialBalance;
  final DateTime createdAt;
  final DateTime updatedAt;

  const WalletModel({
    required this.id,
    required this.name,
    required this.currency,
    required this.initialBalance,
    required this.createdAt,
    required this.updatedAt,
  });

  @override
  List<Object?> get props => [id, name, currency, initialBalance, createdAt, updatedAt];

  WalletModel copyWith({
    String? id,
    String? name,
    String? currency,
    int? initialBalance,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return WalletModel(
      id: id ?? this.id,
      name: name ?? this.name,
      currency: currency ?? this.currency,
      initialBalance: initialBalance ?? this.initialBalance,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

// lib/domain/models/category_model.dart
class CategoryModel extends Equatable {
  final String id;
  final String name;
  final String type; // 'expense' or 'income'
  final String icon;
  final String color;
  final DateTime createdAt;

  const CategoryModel({
    required this.id,
    required this.name,
    required this.type,
    required this.icon,
    required this.color,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [id, name, type, icon, color, createdAt];

  CategoryModel copyWith({
    String? id,
    String? name,
    String? type,
    String? icon,
    String? color,
    DateTime? createdAt,
  }) {
    return CategoryModel(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      icon: icon ?? this.icon,
      color: color ?? this.color,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

// lib/domain/models/transaction_model.dart
class TransactionModel extends Equatable {
  final String id;
  final String? title;
  final int amount;
  final String type; // 'expense' or 'income'
  final DateTime date;
  final String walletId;
  final String categoryId;
  final String? note;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? metadata;

  const TransactionModel({
    required this.id,
    this.title,
    required this.amount,
    required this.type,
    required this.date,
    required this.walletId,
    required this.categoryId,
    this.note,
    required this.createdAt,
    required this.updatedAt,
    this.metadata,
  });

  @override
  List<Object?> get props => [
        id,
        title,
        amount,
        type,
        date,
        walletId,
        categoryId,
        note,
        createdAt,
        updatedAt,
        metadata,
      ];

  TransactionModel copyWith({
    String? id,
    String? title,
    int? amount,
    String? type,
    DateTime? date,
    String? walletId,
    String? categoryId,
    String? note,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? metadata,
  }) {
    return TransactionModel(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      date: date ?? this.date,
      walletId: walletId ?? this.walletId,
      categoryId: categoryId ?? this.categoryId,
      note: note ?? this.note,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      metadata: metadata ?? this.metadata,
    );
  }
}
