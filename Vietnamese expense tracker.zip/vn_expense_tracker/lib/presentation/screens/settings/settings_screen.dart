import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cài đặt'),
      ),
      body: ListView(
        children: [
          _buildSection(
            context,
            'Tài khoản',
            [
              ListTile(
                leading: Icon(Icons.account_balance_wallet),
                title: Text('Quản lý ví'),
                trailing: Icon(Icons.chevron_right),
                onTap: () {},
              ),
              ListTile(
                leading: Icon(Icons.category),
                title: Text('Quản lý danh mục'),
                trailing: Icon(Icons.chevron_right),
                onTap: () {},
              ),
            ],
          ),
          _buildSection(
            context,
            'Sao lưu',
            [
              ListTile(
                leading: Icon(Icons.cloud_upload),
                title: Text('Sao lưu lên Google Drive'),
                onTap: () {},
              ),
              ListTile(
                leading: Icon(Icons.cloud_download),
                title: Text('Khôi phục từ sao lưu'),
                onTap: () {},
              ),
              ListTile(
                leading: Icon(Icons.file_download),
                title: Text('Xuất CSV'),
                onTap: () {},
              ),
            ],
          ),
          _buildSection(
            context,
            'Giao diện',
            [
              ListTile(
                leading: Icon(Icons.dark_mode),
                title: Text('Chế độ tối'),
                trailing: Switch(value: false, onChanged: (v) {}),
              ),
              ListTile(
                leading: Icon(Icons.language),
                title: Text('Ngôn ngữ'),
                subtitle: Text('Tiếng Việt'),
                trailing: Icon(Icons.chevron_right),
                onTap: () {},
              ),
            ],
          ),
          _buildSection(
            context,
            'Bảo mật',
            [
              ListTile(
                leading: Icon(Icons.lock),
                title: Text('Mã PIN'),
                trailing: Switch(value: false, onChanged: (v) {}),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    List<Widget> children,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.grey,
                ),
          ),
        ),
        ...children,
        const Divider(),
      ],
    );
  }
}
