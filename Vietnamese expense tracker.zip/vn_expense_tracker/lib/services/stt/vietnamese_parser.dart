// lib/services/stt/vietnamese_parser.dart
import 'dart:core';

class VietnameseNumberParser {
  // Vietnamese number words mapping
  static const Map<String, int> numberWords = {
    'không': 0,
    'một': 1,
    'hai': 2,
    'ba': 3,
    'bốn': 4,
    'năm': 5,
    'sáu': 6,
    'bảy': 7,
    'tám': 8,
    'chín': 9,
    'mười': 10,
    'trăm': 100,
    'nghìn': 1000,
    'ngàn': 1000,
    'vạn': 10000,
    'triệu': 1000000,
    'tỷ': 1000000000,
  };

  // Parse amount from Vietnamese text
  static int? parseAmount(String text) {
    text = text.toLowerCase().trim();

    // Try to parse numeric shortcuts first (e.g., "100k", "1.5tr")
    final shortcutMatch = RegExp(r'(\d+(?:\.\d+)?)\s*(k|tr|triệu|tỷ)?').firstMatch(text);
    if (shortcutMatch != null) {
      final number = double.tryParse(shortcutMatch.group(1) ?? '0') ?? 0;
      final unit = shortcutMatch.group(2) ?? '';

      switch (unit) {
        case 'k':
          return (number * 1000).toInt();
        case 'tr':
        case 'triệu':
          return (number * 1000000).toInt();
        case 'tỷ':
          return (number * 1000000000).toInt();
        default:
          return number.toInt();
      }
    }

    // Parse Vietnamese number words
    int total = 0;
    int current = 0;
    final words = text.split(RegExp(r'\s+'));

    for (final word in words) {
      if (numberWords.containsKey(word)) {
        final value = numberWords[word]!;
        if (value >= 1000) {
          current *= value;
          total += current;
          current = 0;
        } else if (value >= 100) {
          current *= value;
        } else {
          current += value;
        }
      }
    }

    return total + current;
  }
}

class VietnameseTransactionParser {
  // Transaction type keywords
  static const List<String> expenseKeywords = [
    'chi',
    'tiêu',
    'trả',
    'mua',
    'đóng',
    'nộp',
    'thanh toán',
  ];

  static const List<String> incomeKeywords = [
    'thu',
    'nhận',
    'lương',
    'thưởng',
    'bán',
  ];

  // Category keywords
  static const Map<String, List<String>> categoryKeywords = {
    'food': ['ăn', 'uống', 'cơm', 'quán', 'nhà hàng', 'cafe', 'trà sữa'],
    'transport': ['xe', 'grab', 'taxi', 'xăng', 'đi', 'về', 'bus'],
    'shopping': ['mua', 'sắm', 'quần áo', 'giày', 'siêu thị'],
    'entertainment': ['vui', 'chơi', 'xem phim', 'du lịch', 'game'],
    'bills': ['điện', 'nước', 'điện thoại', 'internet', 'nhà'],
    'healthcare': ['thuốc', 'bệnh viện', 'khám', 'y tế'],
    'education': ['học', 'sách', 'khóa học', 'trường'],
    'salary': ['lương', 'công ty', 'tiền lương'],
    'bonus': ['thưởng', 'bonus'],
  };

  // Wallet keywords
  static const Map<String, List<String>> walletKeywords = {
    'cash': ['tiền mặt', 'cash'],
    'vietcombank': ['vietcombank', 'vcb', 'vietcom'],
    'techcombank': ['techcombank', 'tcb', 'techcom'],
    'vietinbank': ['vietinbank', 'vtb', 'vietin'],
    'momo': ['momo', 'ví momo'],
    'zalopay': ['zalopay', 'zalo pay'],
  };

  // Date keywords
  static const Map<String, int> dateKeywords = {
    'hôm nay': 0,
    'hôm qua': -1,
    'hôm kia': -2,
    'tuần này': 0,
    'tuần trước': -7,
  };

  static ParsedTransaction parse(String text) {
    text = text.toLowerCase();

    return ParsedTransaction(
      amount: VietnameseNumberParser.parseAmount(text),
      type: _parseType(text),
      category: _parseCategory(text),
      wallet: _parseWallet(text),
      date: _parseDate(text),
      rawText: text,
    );
  }

  static String? _parseType(String text) {
    for (final keyword in expenseKeywords) {
      if (text.contains(keyword)) return 'expense';
    }
    for (final keyword in incomeKeywords) {
      if (text.contains(keyword)) return 'income';
    }
    return null;
  }

  static String? _parseCategory(String text) {
    for (final entry in categoryKeywords.entries) {
      for (final keyword in entry.value) {
        if (text.contains(keyword)) {
          return entry.key;
        }
      }
    }
    return null;
  }

  static String? _parseWallet(String text) {
    for (final entry in walletKeywords.entries) {
      for (final keyword in entry.value) {
        if (text.contains(keyword)) {
          return entry.key;
        }
      }
    }
    return null;
  }

  static DateTime? _parseDate(String text) {
    final now = DateTime.now();

    for (final entry in dateKeywords.entries) {
      if (text.contains(entry.key)) {
        return now.add(Duration(days: entry.value));
      }
    }

    // Try to parse explicit date (dd/mm or dd/mm/yyyy)
    final dateMatch = RegExp(r'(\d{1,2})/(\d{1,2})(?:/(\d{4}))?').firstMatch(text);
    if (dateMatch != null) {
      final day = int.tryParse(dateMatch.group(1) ?? '0') ?? 0;
      final month = int.tryParse(dateMatch.group(2) ?? '0') ?? 0;
      final year = int.tryParse(dateMatch.group(3) ?? now.year.toString()) ?? now.year;

      if (day > 0 && day <= 31 && month > 0 && month <= 12) {
        return DateTime(year, month, day);
      }
    }

    return null;
  }
}

class ParsedTransaction {
  final int? amount;
  final String? type;
  final String? category;
  final String? wallet;
  final DateTime? date;
  final String rawText;

  ParsedTransaction({
    this.amount,
    this.type,
    this.category,
    this.wallet,
    this.date,
    required this.rawText,
  });

  bool get isComplete {
    return amount != null && type != null && category != null;
  }

  List<String> get missingFields {
    final missing = <String>[];
    if (amount == null) missing.add('amount');
    if (type == null) missing.add('type');
    if (category == null) missing.add('category');
    return missing;
  }

  @override
  String toString() {
    return 'ParsedTransaction(amount: $amount, type: $type, category: $category, wallet: $wallet, date: $date)';
  }
}
