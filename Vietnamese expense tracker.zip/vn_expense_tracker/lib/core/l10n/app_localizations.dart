import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static const List<Locale> supportedLocales = [
    Locale('vi', ''),
    Locale('en', ''),
  ];

  static final Map<String, Map<String, String>> _localizedValues = {
    'vi': {
      'app_title': 'Quản Lý Chi Tiêu',
      'dashboard': 'Tổng quan',
      'history': 'Lịch sử',
      'add': 'Thêm',
      'statistics': 'Thống kê',
      'settings': 'Cài đặt',
    },
    'en': {
      'app_title': 'Expense Tracker',
      'dashboard': 'Dashboard',
      'history': 'History',
      'add': 'Add',
      'statistics': 'Statistics',
      'settings': 'Settings',
    },
  };

  String translate(String key) {
    return _localizedValues[locale.languageCode]?[key] ?? key;
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['vi', 'en'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
