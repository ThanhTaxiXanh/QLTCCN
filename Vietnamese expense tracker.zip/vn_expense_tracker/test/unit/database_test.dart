// test/unit/database_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:vn_expense_tracker/data/local/database.dart';
import 'package:drift/native.dart';
import 'package:uuid/uuid.dart';

void main() {
  late AppDatabase database;
  const uuid = Uuid();

  setUp(() {
    // Create in-memory database for testing
    database = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await database.close();
  });

  group('Wallet Operations', () {
    test('should create wallet successfully', () async {
      final walletId = uuid.v4();
      final now = DateTime.now();

      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          currency: const Value('VND'),
          initialBalance: 1000000,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final wallet = await database.getWalletById(walletId);
      expect(wallet, isNotNull);
      expect(wallet!.name, equals('Test Wallet'));
      expect(wallet.initialBalance, equals(1000000));
    });

    test('should prevent deleting wallet with transactions', () async {
      final walletId = 'wallet_test';
      final categoryId = 'cat_test';
      final now = DateTime.now();

      // Create wallet
      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          initialBalance: 0,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Create category
      await database.insertCategory(
        CategoriesCompanion.insert(
          id: categoryId,
          name: 'Test Category',
          type: 'expense',
          icon: '🧪',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      // Create transaction
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 50000,
          type: 'expense',
          date: now,
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Check that wallet has transactions
      final hasTransactions = await database.walletHasTransactions(walletId);
      expect(hasTransactions, isTrue);
    });

    test('should calculate wallet balance correctly', () async {
      final walletId = 'wallet_balance_test';
      final categoryId = 'cat_balance_test';
      final now = DateTime.now();

      // Create wallet with initial balance
      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Balance Test Wallet',
          initialBalance: 1000000,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Create category
      await database.insertCategory(
        CategoriesCompanion.insert(
          id: categoryId,
          name: 'Test Category',
          type: 'expense',
          icon: '🧪',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      // Add income transaction
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 500000,
          type: 'income',
          date: now,
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Add expense transaction
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 300000,
          type: 'expense',
          date: now,
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final balance = await database.getWalletBalance(walletId);
      
      // Initial: 1,000,000 + Income: 500,000 - Expense: 300,000 = 1,200,000
      expect(balance['balance'], equals(1200000));
      expect(balance['income'], equals(500000));
      expect(balance['expense'], equals(300000));
    });
  });

  group('Category Operations', () {
    test('should reassign transactions when deleting category', () async {
      final now = DateTime.now();
      final walletId = 'wallet_cat_test';
      final oldCategoryId = 'cat_old';
      final newCategoryId = 'cat_new';

      // Setup: Create wallet
      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          initialBalance: 0,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Create two categories
      await database.insertCategory(
        CategoriesCompanion.insert(
          id: oldCategoryId,
          name: 'Old Category',
          type: 'expense',
          icon: '🗑️',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      await database.insertCategory(
        CategoriesCompanion.insert(
          id: newCategoryId,
          name: 'New Category',
          type: 'expense',
          icon: '✨',
          color: '00FF00',
          createdAt: now,
        ),
      );

      // Create transactions in old category
      final txnId1 = uuid.v4();
      final txnId2 = uuid.v4();

      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: txnId1,
          amount: 100000,
          type: 'expense',
          date: now,
          walletId: walletId,
          categoryId: oldCategoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: txnId2,
          amount: 200000,
          type: 'expense',
          date: now,
          walletId: walletId,
          categoryId: oldCategoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Verify transactions are in old category
      final countBefore = await database.getCategoryTransactionCount(oldCategoryId);
      expect(countBefore, equals(2));

      // Delete old category with reassignment
      await database.deleteCategoryWithReassignment(oldCategoryId, newCategoryId);

      // Verify old category is deleted
      final oldCategory = await database.getCategoryById(oldCategoryId);
      expect(oldCategory, isNull);

      // Verify transactions are reassigned
      final countAfter = await database.getCategoryTransactionCount(newCategoryId);
      expect(countAfter, equals(2));

      // Verify specific transactions
      final txn1 = await database.getAllTransactions();
      expect(txn1.where((t) => t.id == txnId1).first.categoryId, equals(newCategoryId));
      expect(txn1.where((t) => t.id == txnId2).first.categoryId, equals(newCategoryId));
    });

    test('should get transaction count for category', () async {
      final now = DateTime.now();
      final walletId = 'wallet_count_test';
      final categoryId = 'cat_count_test';

      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          initialBalance: 0,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertCategory(
        CategoriesCompanion.insert(
          id: categoryId,
          name: 'Count Category',
          type: 'expense',
          icon: '📊',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      // Add 3 transactions
      for (int i = 0; i < 3; i++) {
        await database.insertTransaction(
          TransactionsCompanion.insert(
            id: uuid.v4(),
            amount: 50000,
            type: 'expense',
            date: now,
            walletId: walletId,
            categoryId: categoryId,
            createdAt: now,
            updatedAt: now,
          ),
        );
      }

      final count = await database.getCategoryTransactionCount(categoryId);
      expect(count, equals(3));
    });
  });

  group('Transaction Aggregation', () {
    test('should aggregate income and expense for period', () async {
      final now = DateTime.now();
      final walletId = 'wallet_agg_test';
      final categoryId = 'cat_agg_test';

      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          initialBalance: 0,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertCategory(
        CategoriesCompanion.insert(
          id: categoryId,
          name: 'Agg Category',
          type: 'expense',
          icon: '📈',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      final startDate = DateTime(2024, 1, 1);
      final endDate = DateTime(2024, 1, 31);

      // Add income
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 5000000,
          type: 'income',
          date: DateTime(2024, 1, 15),
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Add expenses
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 1000000,
          type: 'expense',
          date: DateTime(2024, 1, 10),
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 500000,
          type: 'expense',
          date: DateTime(2024, 1, 20),
          walletId: walletId,
          categoryId: categoryId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final result = await database.getIncomeExpenseForPeriod(
        startDate,
        endDate,
        walletId: walletId,
      );

      expect(result['income'], equals(5000000));
      expect(result['expense'], equals(1500000));
      expect(result['net'], equals(3500000));
    });

    test('should get category breakdown correctly', () async {
      final now = DateTime.now();
      final walletId = 'wallet_breakdown_test';
      final category1Id = 'cat_food';
      final category2Id = 'cat_transport';

      await database.insertWallet(
        WalletsCompanion.insert(
          id: walletId,
          name: 'Test Wallet',
          initialBalance: 0,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertCategory(
        CategoriesCompanion.insert(
          id: category1Id,
          name: 'Food',
          type: 'expense',
          icon: '🍔',
          color: 'FF0000',
          createdAt: now,
        ),
      );

      await database.insertCategory(
        CategoriesCompanion.insert(
          id: category2Id,
          name: 'Transport',
          type: 'expense',
          icon: '🚗',
          color: '00FF00',
          createdAt: now,
        ),
      );

      final startDate = DateTime(2024, 1, 1);
      final endDate = DateTime(2024, 1, 31);

      // Add transactions to different categories
      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 300000,
          type: 'expense',
          date: DateTime(2024, 1, 10),
          walletId: walletId,
          categoryId: category1Id,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 150000,
          type: 'expense',
          date: DateTime(2024, 1, 15),
          walletId: walletId,
          categoryId: category1Id,
          createdAt: now,
          updatedAt: now,
        ),
      );

      await database.insertTransaction(
        TransactionsCompanion.insert(
          id: uuid.v4(),
          amount: 200000,
          type: 'expense',
          date: DateTime(2024, 1, 20),
          walletId: walletId,
          categoryId: category2Id,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final breakdown = await database.getCategoryBreakdown(
        startDate,
        endDate,
        'expense',
        walletId: walletId,
      );

      expect(breakdown[category1Id], equals(450000));
      expect(breakdown[category2Id], equals(200000));
    });
  });
}

// Extension for testing database
extension TestDatabase on AppDatabase {
  static AppDatabase forTesting(QueryExecutor executor) {
    final db = AppDatabase();
    return db;
  }
}
