# VN Expense Tracker

A comprehensive personal expense and income tracker application optimized for the Vietnamese market, built with Flutter.

## Features

### Core Functionality
- **Offline-First Architecture**: All features work without internet connection
- **Multi-Wallet Support**: Manage multiple wallets with different currencies
- **Smart Categorization**: Customizable income and expense categories with icons and colors
- **Voice Input**: Vietnamese language voice-to-transaction feature with intelligent parsing
- **Comprehensive Statistics**: Visual charts and analytics with period comparisons
- **Lunar Calendar Integration**: Vietnamese lunar calendar support for transactions

### Key Capabilities
- Create, edit, and delete transactions with minimal friction
- Category reassignment when deleting categories (prevents data loss)
- Monthly calendar view with daily income/expense indicators
- Financial analytics with line charts and donut charts
- Google Drive backup and restore
- CSV export for data portability
- Optional PIN lock for security
- Light/Dark theme support
- Vietnamese and English localization

## Technical Stack

- **Framework**: Flutter (Stable Channel)
- **State Management**: Riverpod
- **Local Database**: Drift (SQLite)
- **Charts**: FL Chart
- **Voice Recognition**: Speech-to-Text with abstraction layer
- **Architecture**: Clean Architecture (Data/Domain/Presentation layers)

## Project Structure

```
lib/
├── core/
│   ├── l10n/              # Localization files
│   ├── router/            # Navigation and routing
│   ├── theme/             # App theming
│   └── utils/             # Utility functions
├── data/
│   ├── local/             # Database implementation
│   └── repositories/      # Repository implementations
├── domain/
│   ├── models/            # Domain models
│   └── repositories/      # Repository interfaces
├── presentation/
│   ├── providers/         # Riverpod providers
│   ├── screens/           # UI screens
│   └── widgets/           # Reusable widgets
└── services/              # External services (STT, backup, etc.)
```

## Getting Started

### Prerequisites

- Flutter SDK (3.0.0 or higher)
- Dart SDK (3.0.0 or higher)
- Android Studio / Xcode for platform-specific builds
- Git

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd vn_expense_tracker
```

2. Install dependencies:
```bash
flutter pub get
```

3. Generate Drift database code:
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

4. Run the app:
```bash
# For Android
flutter run

# For iOS
flutter run -d ios

# For Web
flutter run -d chrome
```

### Build for Production

#### Android APK
```bash
flutter build apk --release
```

#### Android App Bundle
```bash
flutter build appbundle --release
```

#### iOS
```bash
flutter build ios --release
```

## Configuration

### Database
The app uses Drift (SQLite) for local data storage. The database is initialized automatically on first launch with default categories and a demo wallet.

### Voice Recognition
The app includes an abstraction layer for speech-to-text functionality. You can configure different STT providers by implementing the `SttProvider` interface in `lib/services/stt/`.

### Backup
Google Drive integration requires:
1. Create a Google Cloud project
2. Enable Google Drive API
3. Add OAuth credentials
4. Update `android/app/google-services.json` and `ios/Runner/GoogleService-Info.plist`

## Testing

### Run Unit Tests
```bash
flutter test
```

### Run Integration Tests
```bash
flutter test integration_test/
```

### Test Coverage
```bash
flutter test --coverage
```

## Key Features Implementation

### Category Deletion with Reassignment
When deleting a category that contains transactions, users must select a replacement category. This ensures data integrity and prevents orphaned transactions.

```dart
// Atomic database operation
await database.deleteCategoryWithReassignment(categoryId, replacementId);
```

### Voice Input Parsing
The app parses Vietnamese voice inputs to extract:
- Amount (supports "100k", "1.5 triệu", number words)
- Transaction type (expense/income keywords)
- Category (fuzzy matching)
- Wallet (bank names, cash, card)
- Date (relative and absolute)

### Aggregation Queries
Efficient SQL queries for:
- Current wallet balance
- Income/expense by period
- Category breakdown
- Month-over-month comparisons

## Localization

The app supports Vietnamese (default) and English. Localization files are in:
- `lib/core/l10n/app_vi.arb` (Vietnamese)
- `lib/core/l10n/app_en.arb` (English)

## Security

- Optional PIN lock (4-6 digits)
- Local PIN hashing using crypto package
- No sensitive data transmitted externally
- Offline-first design minimizes attack surface

## Performance Optimizations

- Lazy loading for transaction lists
- Efficient database indexing
- Minimal rebuild with Riverpod
- Image caching for category icons
- Debounced search inputs

## Known Limitations

- Google Drive sync is manual (no automatic background sync)
- Voice recognition requires internet connection
- PIN lock is local only (no cloud recovery)

## Future Enhancements

- Recurring transactions
- Multi-currency support with exchange rates
- Biometric authentication
- Cloud sync with conflict resolution
- Budget planning and alerts
- Receipt photo attachment
- Shared wallets for family

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Vietnamese lunar calendar algorithm from traditional Vietnamese astronomy
- Icons from Material Design
- Vietnamese number parsing inspired by common Vietnamese speech patterns

## Support

For issues, questions, or feature requests, please create an issue in the repository.

## Changelog

### Version 1.0.0 (Initial Release)
- Complete offline expense tracking
- Vietnamese voice input
- Category management with reassignment
- Google Drive backup
- CSV export
- Lunar calendar integration
- Light/Dark themes
- PIN lock security
