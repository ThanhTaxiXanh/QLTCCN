# VN Expense Tracker - Development Guide

## Project Overview

This is a production-ready Flutter expense tracking application optimized for Vietnamese users. The application is built with clean architecture, offline-first design, and includes comprehensive features for personal finance management.

## Architecture Overview

### Layer Structure

**Presentation Layer** (`lib/presentation/`)
- Screens: Dashboard, History, Statistics, Settings, Transaction Management
- Widgets: Reusable UI components
- Providers: Riverpod state management

**Domain Layer** (`lib/domain/`)
- Models: Domain entities (Wallet, Category, Transaction, Lunar)
- Repository Interfaces: Contracts for data operations

**Data Layer** (`lib/data/`)
- Local Database: Drift/SQLite implementation
- Repositories: Concrete implementations

**Services** (`lib/services/`)
- Speech-to-Text: Vietnamese voice recognition and parsing
- Backup: Google Drive integration
- Lunar Calendar: Vietnamese calendar calculations

### Key Technologies

- **State Management**: Flutter Riverpod for reactive state
- **Database**: Drift (SQLite wrapper) for type-safe queries
- **Localization**: Support for Vietnamese (default) and English
- **Voice Input**: Speech-to-Text with Vietnamese number parsing
- **Charts**: FL Chart for financial visualizations

## Database Schema

### Tables

**wallets**
- id (TEXT PRIMARY KEY)
- name (TEXT)
- currency (TEXT, default 'VND')
- initial_balance (INTEGER)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)

**categories**
- id (TEXT PRIMARY KEY)
- name (TEXT)
- type (TEXT: 'expense' | 'income')
- icon (TEXT: emoji)
- color (TEXT: hex code)
- created_at (TIMESTAMP)

**transactions**
- id (TEXT PRIMARY KEY)
- title (TEXT, nullable)
- amount (INTEGER: stored in smallest currency unit)
- type (TEXT: 'expense' | 'income')
- date (DATE)
- wallet_id (FK → wallets.id)
- category_id (FK → categories.id)
- note (TEXT, nullable)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
- metadata (TEXT: JSON string, nullable)

**settings**
- key (TEXT PRIMARY KEY)
- value (TEXT)

**backups**
- id (TEXT PRIMARY KEY)
- path (TEXT)
- created_at (TIMESTAMP)

## Critical Features Implementation

### Category Deletion with Reassignment

When a user attempts to delete a category that contains transactions, the system enforces a mandatory reassignment flow:

1. Query transaction count for the target category
2. If count > 0, display reassignment modal
3. User must select a replacement category of the same type
4. Execute atomic database transaction to reassign all transactions
5. Delete the original category

This is implemented in `database.dart` as `deleteCategoryWithReassignment()`.

### Vietnamese Voice Input Parsing

The voice input system includes intelligent parsing for Vietnamese language patterns:

**Amount Parsing**
- Numeric shortcuts: "100k" → 100,000, "1.5 triệu" → 1,500,000
- Vietnamese number words: "một trăm nghìn" → 100,000
- Decimal support: "1.5 triệu" → 1,500,000

**Transaction Type Detection**
- Expense keywords: chi, tiêu, trả, mua, đóng, nộp
- Income keywords: thu, nhận, lương, thưởng, bán

**Category Matching**
- Fuzzy keyword matching across 12 default categories
- Supports Vietnamese-specific terms

**Wallet Detection**
- Bank names: Vietcombank, Techcombank, Vietinbank
- E-wallets: MoMo, ZaloPay
- Cash wallet recognition

**Date Parsing**
- Relative dates: "hôm nay", "hôm qua", "tuần trước"
- Explicit dates: "15/01" or "15/01/2024"

Implementation in `lib/services/stt/vietnamese_parser.dart`.

### Lunar Calendar Integration

Vietnamese lunar calendar support provides:
- Solar to lunar date conversion
- Can Chi (天干地支) calculations for day, month, and year
- Auspicious hours (Giờ Hoàng Đạo) for each day
- Leap month detection

This enables users to view transactions in the traditional Vietnamese calendar system, which is culturally significant for Vietnamese users.

## Data Flow Examples

### Adding a Transaction

1. User taps FAB or navigates to Add Transaction screen
2. User enters or speaks transaction details
3. If voice input: Parse Vietnamese text → Extract structured data
4. Display preview with highlighted missing fields
5. User confirms → Create TransactionsCompanion object
6. Insert into database via `database.insertTransaction()`
7. Riverpod notifies listeners → UI updates
8. Navigate back to dashboard with updated balance

### Viewing Statistics

1. User selects time period and wallet filter
2. Provider queries database via `getIncomeExpenseForPeriod()`
3. Calculate category breakdown via `getCategoryBreakdown()`
4. Compute period-over-period changes
5. Render FL Chart components with aggregated data
6. Display summary KPIs

## Testing Strategy

### Unit Tests
- Database CRUD operations
- Category reassignment logic
- Vietnamese number parsing
- Aggregation query correctness
- Date range calculations

### Integration Tests
- Complete transaction workflow
- Voice input end-to-end
- Category deletion with reassignment
- Multi-wallet balance calculations

### Widget Tests
- Form validation
- UI state transitions
- Error handling displays

Run tests with:
```bash
flutter test
flutter test --coverage
```

## Build and Deployment

### Development Build
```bash
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
flutter run
```

### Production Android
```bash
flutter build apk --release
flutter build appbundle --release
```

### Production iOS
```bash
flutter build ios --release
```

## Performance Considerations

### Database Optimization
- Indexed foreign keys for faster joins
- Lazy loading for transaction lists
- Efficient aggregation queries using native SQL
- In-memory caching of frequently accessed data

### UI Performance
- IndexedStack for bottom navigation (preserves state)
- Lazy building of transaction list items
- Debounced search inputs
- Optimized chart rendering with FL Chart

### Memory Management
- Proper disposal of TextEditingControllers
- Stream subscription cleanup
- Image caching for category icons

## Security Implementation

### PIN Lock
- 4-6 digit PIN stored as SHA-256 hash
- Local-only verification (no cloud transmission)
- Configurable in Settings
- Auto-lock after app backgrounding

### Data Privacy
- All data stored locally in encrypted SQLite database
- Optional Google Drive backup requires explicit user consent
- No analytics or tracking
- No external network calls except for voice recognition and backup

## Localization

Currently supported languages:
- Vietnamese (vi) - Default
- English (en)

Add new translations in `lib/core/l10n/app_localizations.dart`.

## Known Limitations

1. Voice recognition requires internet connection
2. Google Drive sync is manual (no real-time sync)
3. PIN recovery not available (local only)
4. Single currency per wallet
5. No recurring transactions in v1.0

## Future Roadmap

### Phase 2
- Recurring transactions (daily, weekly, monthly)
- Budget planning with alerts
- Receipt photo attachment
- Biometric authentication

### Phase 3
- Multi-currency support with exchange rates
- Cloud sync with conflict resolution
- Shared wallets for families
- Advanced reporting (PDF export)

### Phase 4
- Machine learning category suggestions
- Spending pattern analysis
- Financial goal tracking
- Integration with bank APIs

## Contributing

### Code Style
- Follow Dart style guide
- Use meaningful variable names
- Comment complex logic
- Write tests for new features

### Pull Request Process
1. Create feature branch from main
2. Implement feature with tests
3. Update documentation
4. Submit PR with description
5. Address review comments

## Troubleshooting

### Database Schema Changes
If you modify the database schema:
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

### Voice Recognition Issues
- Check microphone permissions in app settings
- Ensure internet connectivity
- Verify device language is set to Vietnamese

### Build Errors
- Clean build: `flutter clean && flutter pub get`
- Update dependencies: `flutter pub upgrade`
- Check Flutter version: `flutter doctor`

## Support and Maintenance

For issues, questions, or feature requests:
1. Check existing GitHub issues
2. Review this documentation
3. Create new issue with reproduction steps

## License

MIT License - See LICENSE file for details
